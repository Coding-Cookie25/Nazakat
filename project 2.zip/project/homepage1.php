<?php 
session_start();
include("connect.php");

if(!isset($_SESSION['email'])){
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Page</title>
    <link rel="stylesheet" href="dropdownstyle.css">
    <style>
        /* Additional styling for the profile page */
        .profile-container {
            max-width: 600px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            margin: 50px auto;
            padding: 2rem;
            text-align: center;
        }
        .profile-greeting {
            font-size: 2rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 1rem;
        }
        .profile-details p {
            font-size: 1.1rem;
            margin: 0.5rem 0;
            color: #555;
        }
        .profile-details strong {
            color: #333;
        }
        .logout-btn {
            display: inline-block;
            margin-top: 20px;
            background-color: #DE3163;
            color: white;
            padding: 10px 20px;
            font-size: 1rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
        }
        .logout-btn:hover {
            background-color: #c42753;
        }
        .bg{
            background: linear-gradient(to bottom, #ffcccb, #ffe4e1);
        }
    </style>
</head>
<header>
        <div class="header-container">
            <div class="logo">
                <a class="h" href="homepage.php"> <h1> NAZAKAT</h1></a>
            </div>
            <nav>
                <ul class="nav-links">
                    <li class="dropdown">
                        <a href="skincare.html">Skin Care</a>
                        <div class="dropdown-content">
                            <a href="moisturizerportfolio.html">Moisturizers</a>
                            <a href="serumportfolio.html">Serums</a>
                            <a href="cleanserportfolio.html">Cleansers</a>
                            <a href="sunscreenportfolio.html">Sunscreen</a>

                        </div>
                    </li>
                    <li class="dropdown">
                      <a href="bodycare.html">Body Care</a>
                      <div class="dropdown-content">
                        <a href="bodylotions.html"> BodyLotions</a>
                        <a href="bodywashes.html">Body Wash</a>
                        <a href="bodyscrubs.html">Body Scrubs</a>
                        <a href="bodymists.html">Body Mists</a>
                      </div>
                  </li>
                    <li class="dropdown">
                        <a href="haircare.html">Hair Care</a>
                        <div class="dropdown-content">
                            <a href="shampoo.html">Shampoo</a>
                            <a href="conditioner.html">Conditioner</a>
                            <a href="hserum.html">Serums</a>
                            <a href="hairmask.html">Hair Mask</a>

                        </div>
                    </li>
                </ul>
            </nav>
            <div class="right-section">
                <ul>
                    <li><a href="homepage1.php"><img src="Unknown-5.png" alt="Account" /></a></li>
                    <li><a href="cart.php"><img src="Unknown-4.png" alt="Cart" /></a><span class="cart-count">0</span></li>
                </ul>
            </div>
        </div>
        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="Search..." />
            <button onclick="performSearch()">Search</button>
        </div>
    </header>  <br> <br><br>
<body class="bg">
    <div class="profile-container">
        <u><h1 class="form-title">Profile</h1></u>
        
        <?php 
        if(isset($_SESSION['email'])){
            $email = $_SESSION['email'];
            $query = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
            if($row = mysqli_fetch_array($query)){
                echo "<p class='profile-greeting'>Hello, " . $row['fname'] . " " . $row['lname'] . "!</p>";
                echo "<div class='profile-details'>";
                echo "<p><strong>Email:</strong> " . $row['email'] . "</p>";
                 // Check if address key exists in the row and is not empty
                 if (isset($row['Address']) && !empty($row['Address'])) {
                    echo "<p><strong>Address:</strong> " . $row['Address'] . "</p>";
                } else {
                    echo "<p><strong>Address:</strong> Not provided</p>";
                }
                echo "</div>";
            }
        }
        ?>

        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
    <br><br><br>
    <footer>
        <div class="footer-links">
            <ul>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms & Conditions</a></li>
            </ul>
        </div>
        <div class="social-media">
            <a href="#">Facebook</a> | 
            <a href="#">Instagram</a> | 
            <a href="#">Twitter</a>
        </div>
        <p>&copy; 2023 Nazakat. All rights reserved.</p>
    </footer>
</body>
</html>
