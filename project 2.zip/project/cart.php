<!-- cart.php -->
<?php

include 'connect.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['quantity'] = $quantity;
    }

    header("Location: cart.php");
    exit();
}

$total = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="cart.css">
</head>
<header>
        <div class="header-container">
            <div class="logo">
                <a class="h" href="homepage.php"> <h1> NAZAKAT</h1></a>
            </div>
            <nav>
                <ul class="nav-links">
                    <li class="dropdown">
                        <a href="skincare.html">Skin Care</a>
                        <div class="dropdown-content">
                            <a href="moisturizerportfolio.php">Moisturizers</a>
                            <a href="serumportfolio.html">Serums</a>
                            <a href="cleanserportfolio.html">Cleansers</a>
                            <a href="sunscreenportfolio.html">Sunscreen</a>

                        </div>
                    </li>
                    <li class="dropdown">
                      <a href="bodycare.html">Body Care</a>
                      <div class="dropdown-content">
                        <a href="bodylotions.html"> BodyLotions</a>
                        <a href="bodywashes.html">Body Wash</a>
                        <a href="bodyscrubs.html">Body Scrubs</a>
                        <a href="bodymists.html">Body Mists</a>
                      </div>
                  </li>
                    <li class="dropdown">
                        <a href="haircare.html">Hair Care</a>
                        <div class="dropdown-content">
                            <a href="shampoo.html">Shampoo</a>
                            <a href="conditioner.html">Conditioner</a>
                            <a href="hserum.html">Serums</a>
                            <a href="hairmask.html">Hair Mask</a>

                        </div>
                    </li>
                </ul>
            </nav>
            <div class="right-section">
                <ul>
                    <li><a href="homepage1.php"><img src="Unknown-5.png" alt="Account" /></a></li>
                    <li><a href="cart.php"><img src="Unknown-4.png" alt="Cart" /></a><span class="cart-count">0</span></li>
                </ul>
            </div>
        </div>
        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="Search..." />
            <button onclick="performSearch()">Search</button>
        </div>
    </header>  <br> <br><br>
<body>
<div class="container">
   <u> <h1>Your Cart</h1></u>
    <table>
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total</th>
            <th>Action</th>
        </tr>
        <?php if (!empty($_SESSION['cart'])): ?>
            <?php foreach ($_SESSION['cart'] as $id => $product): ?>
                <tr>
                    <td><?= htmlspecialchars($product['name']) ?></td>
                    <td>₹<?= number_format($product['price'], 2) ?></td>
                    <td><?= htmlspecialchars($product['quantity']) ?></td>
                    <td>₹<?= number_format($product['price'] * $product['quantity'], 2) ?></td>
                    <td>
                        <form action="update_cart.php" method="post" style="display:inline;">
                            <input type="hidden" name="product_id" value="<?= $id ?>">
                            <input type="number" name="quantity" value="<?= $product['quantity'] ?>" min="1">
                            <button type="submit">Update</button><br>
                        </form>
                        <form action="remove_from_cart.php" method="post" style="display:inline;">
                            <input type="hidden" name="product_id" value="<?= $id ?>">
                            <button type="submit">Remove</button><br>
                        </form>
                    </td>
                </tr>
                <?php $total += $product['price'] * $product['quantity']; ?>
            <?php endforeach; ?>
            <tr>
                <td colspan="3">Total</td>
                <td>₹<?= number_format($total, 2) ?></td>
                <td></td>
            </tr>
        <?php else: ?>
            <tr>
                <td colspan="5">Your cart is empty.</td>
            </tr>
        <?php endif; ?>
        <form action="add_to_cart.php" method="post">
    <button type="submit">Save Cart</button>
</form>
    </table></div>
    <br><br><br>
    <footer>
        <div class="footer-links">
            <ul>
                <li><a href="aboutus.html">About Us</a></li>
                <li><a href="c.html">Contact</a></li>
                <li><a href="pp.html">Privacy Policy</a></li>
                <li><a href="t&c.html">Terms & Conditions</a></li>
            </ul>
        </div>
        <div class="social-media">
            <a href="#">Facebook</a> | 
            <a href="#">Instagram</a> | 
            <a href="#">Twitter</a>
        </div>
        <p>&copy; 2023 Nazakat. All rights reserved.</p>
    </footer>
</body>
</html>

