<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'];
    $quantity = isset($_POST['quantity']) ? $_POST['quantity'] : 1;

    // Retrieve product details from database
    include 'connect.php';
    $sql = "SELECT * FROM products WHERE product_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if ($product) {
        $item = [
            'name' => $product['name'],
            'price' => $product['price'],
            'quantity' => $quantity,
        ];
        $_SESSION['cart'][$product_id] = $item;
    }

    header("Location: cart.php");
    exit();
}
