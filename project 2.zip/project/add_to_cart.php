<?php
include 'connect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id']; // Assuming you store the user ID in session after login
    $total_amount = 0;

    if (!empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $product_id => $product) {
            $quantity = $product['quantity'];
            $price = $product['price'];
            $total_amount += $price * $quantity;

            // Insert each product in the cart into the database
            $sql = "INSERT INTO cart (user_id, product_id, quantity, total) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iiid", $user_id, $product_id, $quantity, $total_amount);
            $stmt->execute();
        }

        // Clear cart after saving to database
        unset($_SESSION['cart']);
        header("Location: confirmation.php"); // Redirect to a confirmation page
    } else {
        echo "Your cart is empty.";
    }
}
?>