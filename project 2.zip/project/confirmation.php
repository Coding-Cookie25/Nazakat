<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="dropdownstyle.css">
<head>
    <meta charset="UTF-8">
    <title>Order Confirmation</title>
</head>
<header>
    <div class="header-container">
        <div class="logo">
            <a class="h" href="homepage.php"> <h1> NAZAKAT</h1></a>
        </div>
        <nav>
            <ul class="nav-links">
                <li class="dropdown">
                    <a href="skincare.html">Skin Care</a>
                    <div class="dropdown-content">
                        <a href="moisturizerportfolio.php">Moisturizers</a>
                        <a href="serumportfolio.html">Serums</a>
                        <a href="cleanserportfolio.html">Cleansers</a>
                        <a href="sunscreenportfolio.html">Sunscreen</a>

                    </div>
                </li>
                <li class="dropdown">
                  <a href="bodycare.html">Body Care</a>
                  <div class="dropdown-content">
                    <a href="bodylotions.html"> BodyLotions</a>
                    <a href="bodywashes.html">Body Wash</a>
                    <a href="bodyscrubs.html">Body Scrubs</a>
                    <a href="bodymists.html">Body Mists</a>
                  </div>
              </li>
                <li class="dropdown">
                    <a href="haircare.html">Hair Care</a>
                    <div class="dropdown-content">
                        <a href="shampoo.html">Shampoo</a>
                        <a href="conditioner.html">Conditioner</a>
                        <a href="hserum.html">Serums</a>
                        <a href="hairmask.html">Hair Mask</a>

                    </div>
                </li>
            </ul>
        </nav>
        <div class="right-section">
          <ul>
            <li><a href="homepage1.php"><img src="Unknown-5.png" alt="Account" /></a></li>
            <li><a href="cart.php"><img src="Unknown-4.png" alt="Cart" /></a><span class="cart-count">0</span></li>
        </ul>
        </div>
    </div>
    <div class="search-bar">
        <input type="text" id="searchInput" placeholder="Search..." />
        <button onclick="performSearch()">Search</button>
    </div>
</header><br>
<br> <br>
<body>
    <div class="container">
    <h1>Your cart has been saved successfully!</h1>
    <p>Thank you for shopping with us.</p>
    <a href="homepage.php">Continue Shopping</a>
    </div>
    <br><br>
  <footer>
    <div class="footer-links">
        <ul>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Contact</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms & Conditions</a></li>
        </ul>
    </div>
    <div class="social-media">
        <a href="#">Facebook</a> | 
        <a href="#">Instagram</a> | 
        <a href="#">Twitter</a>
    </div>
    <p>&copy; 2023 Nazakat. All rights reserved.</p>
</footer>
</body>
</html>