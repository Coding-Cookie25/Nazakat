// Add to Cart Button Functionality for Multiple Products
document.querySelectorAll('.add-to-cart-btn').forEach(button => {
    button.addEventListener('click', function() {
        if (this.classList.contains('added-to-cart')) {
            this.textContent = 'Add to Cart';
            this.classList.remove('added-to-cart');
            this.classList.add('add-to-cart-btn');
        } else {
            this.textContent = 'Added to Cart';
            this.classList.remove('add-to-cart-btn');
            this.classList.add('added-to-cart');
        }
    });
});
