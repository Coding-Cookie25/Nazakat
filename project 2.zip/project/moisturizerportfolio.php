<?php
include 'connect.php';

$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skincare Product Portfolio</title>
    <link rel="stylesheet" href="portfolio.css">
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <a class="h" href="homepage.php"> <h1> NAZAKAT</h1></a>
            </div>
            <nav>
                <ul class="nav-links">
                    <li class="dropdown">
                        <a href="skincare.html">Skin Care</a>
                        <div class="dropdown-content">
                            <a href="moisturizerportfolio.html">Moisturizers</a>
                            <a href="serumportfolio.html">Serums</a>
                            <a href="cleanserportfolio.html">Cleansers</a>
                            <a href="sunscreenportfolio.html">Sunscreen</a>
                        </div>
                    </li>
                    <li class="dropdown">
                      <a href="bodycare.html">Body Care</a>
                      <div class="dropdown-content">
                        <a href="bodylotions.html"> BodyLotions</a>
                        <a href="bodywashes.html">Body Wash</a>
                        <a href="bodyscrubs.html">Body Scrubs</a>
                        <a href="bodymists.html">Body Mists</a>
                      </div>
                  </li>
                    <li class="dropdown">
                        <a href="haircare.html">Hair Care</a>
                        <div class="dropdown-content">
                            <a href="shampoo.html">Shampoo</a>
                            <a href="conditioner.html">Conditioner</a>
                            <a href="hserum.html">Serums</a>
                            <a href="hairmask.html">Hair Mask</a>
                        </div>
                    </li>
                </ul>
            </nav>
            <div class="right-section">
                <ul>
                    <li><a href="homepage1.php"><img src="Unknown-5.png" alt="Account" /></a></li>
                    <li><a href="cart.php"><img src="Unknown-4.png" alt="Cart" /></a><span class="cart-count">0</span></li>
                </ul>
            </div>
        </div>
        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="Search..." />
            <button onclick="performSearch()">Search</button>
        </div>
    </header>  
    <br> <br><br>
    <div class="container">
        <heading>
           <u><h1>Moisturizer</h1></u>
        </heading>
        <section class="portfolio"> 
        <?php while ($product = $result->fetch_assoc()): ?>
    <div class="product-card">
        <form action="manage_cart.php" method="POST">
            <div class="badge peach">NEW LAUNCH</div>
            <div class="badge bm">Moisturizer</div>
            <!-- Display each product's unique image -->
            <a href="<?php echo htmlspecialchars($product['page_url']); ?>">
                <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="Product Image">
            </a>
            <h2><?php echo htmlspecialchars($product['name']); ?></h2>
            <p><?php echo htmlspecialchars($product['description']); ?></p>
            <p class="rating">
                <span class="rating-score">3.84</span>
                <span class="rating-count">(95)</span>
            </p>
            <p class="price">₹<?php echo number_format($product['price'], 2); ?></p>
            <button type="submit" id="addToCartBtn" class="add-to-cart-btn">Add to Cart</button>
            <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
        </form>
    </div>
<?php endwhile; ?>

        </section>
    </div>
    <br><br><br>
    <footer>
        <div class="footer-links">
            <ul>
                <li><a href="aboutus.html">About Us</a></li>
                <li><a href="c.html">Contact</a></li>
                <li><a href="pp.html">Privacy Policy</a></li>
                <li><a href="t&c.html">Terms & Conditions</a></li>
            </ul>
        </div>
        <div class="social-media">
            <a href="#">Facebook</a> | 
            <a href="#">Instagram</a> | 
            <a href="#">Twitter</a>
        </div>
        <p>&copy; 2023 Nazakat. All rights reserved.</p>
    </footer>
    <script src="portfolio.js"></script>
</body>
</html>
