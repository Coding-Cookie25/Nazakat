<?php 

include 'connect.php';

if (isset($_POST['signUp'])) {
    $fname = $_POST['fName'];
    $lname = $_POST['lName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $address = $_POST['address'];

    // Hashing the password with password_hash
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Check if the email already exists
    $checkEmail = "SELECT * FROM users WHERE email=?";
    $stmt = $conn->prepare($checkEmail);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "Email Address Already Exists!";
    } else {
        // Insert the new user record, including the address
        $insertQuery = "INSERT INTO users (fname, lname, email, password, address) 
                        VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("sssss", $fname, $lname, $email, $hashedPassword, $address);
        
        if ($stmt->execute()) {
            header("Location: index.php"); // Redirect after successful registration
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    }
    $stmt->close();
}

if (isset($_POST['signIn'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Fetch user by email
    $sql = "SELECT * FROM users WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Verify the password
        if (password_verify($password, $row['password'])) {
            session_start();
            // Store user_id and email in session
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['email'] = $row['email'];
            header("Location: homepage.php"); // Redirect to homepage after successful login
            exit();
        } else {
            echo "Incorrect Password";
        }
    } else {
        echo "Not Found, Incorrect Email or Password";
    }
    $stmt->close();
}

$conn->close();
?>