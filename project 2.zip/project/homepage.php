<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nazakat - Home</title>
    <link rel="stylesheet" href="dropdownstyle.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <a class="h" href="homepage.php"> <h1> NAZAKAT</h1></a>
            </div>
            <nav>
                <ul class="nav-links">
                    <li class="dropdown">
                        <a href="skincare.html">Skin Care</a>
                        <div class="dropdown-content">
                            <a href="moisturizerportfolio.php">Moisturizers</a>
                            <a href="serumportfolio.html">Serums</a>
                            <a href="cleanserportfolio.html">Cleansers</a>
                            <a href="sunscreenportfolio.html">Sunscreen</a>

                        </div>
                    </li>
                    <li class="dropdown">
                      <a href="bodycare.html">Body Care</a>
                      <div class="dropdown-content">
                        <a href="bodylotions.html"> BodyLotions</a>
                        <a href="bodywashes.html">Body Wash</a>
                        <a href="bodyscrubs.html">Body Scrubs</a>
                        <a href="bodymists.html">Body Mists</a>
                      </div>
                  </li>
                    <li class="dropdown">
                        <a href="haircare.html">Hair Care</a>
                        <div class="dropdown-content">
                            <a href="shampoo.html">Shampoo</a>
                            <a href="conditioner.html">Conditioner</a>
                            <a href="hserum.html">Serums</a>
                            <a href="hairmask.html">Hair Mask</a>

                        </div>
                    </li>
                </ul>
            </nav>
            <div class="right-section">
                <ul>
                    <li><a href="homepage1.php"><img src="Unknown-5.png" alt="Account" /></a></li>
                    <li><a href="cart.php"><img src="Unknown-4.png" alt="Cart" /></a><span class="cart-count">0</span></li>
                </ul>
            </div>
        </div>
        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="Search..." />
            <button onclick="performSearch()">Search</button>
        </div>
    </header>  <br> <br><br>
    <div class="slideshow-container">

        <!-- Slide 1 -->
        <div class="mySlides fade">
           <a href="bodycare.html"> <img src="Screenshot 2024-10-26 at 6.33.28 PM.png" alt="Advertisement 1" class="slide-img"></a>
            <div class="text">Bodycare</div>
        </div>

        <!-- Slide 2 -->
        <div class="mySlides fade">
           <a href="haircare.html"> <img src="Screenshot 2024-10-26 at 4.50.48 PM.png" alt="Advertisement 2" class="slide-img"></a>
            <div class="text">Haircare</div>
        </div>

        <!-- Slide 3 -->
        <div class="mySlides fade">
           <a href="skincare.html"> <img src="Screenshot 2024-10-28 at 3.10.58 PM.png" alt="Advertisement 3" class="slide-img"></a>
            <div class="text">skincare</div>
        </div>

        <!-- Next and previous buttons -->
        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
        <a class="next" onclick="plusSlides(1)">&#10095;</a>

    </div>
    <div style="text-align:center">
        <span class="dot" onclick="currentSlide(1)"></span>
        <span class="dot" onclick="currentSlide(2)"></span>
        <span class="dot" onclick="currentSlide(3)"></span>
    </div>
    <section class="hero">
        <div class="hero-content">
            <h2>Welcome to Nazakat</h2>
            <p>Explore our curated range of high-quality skincare, bodycare, fragrance, and haircare products.</p>
            <a href="shop.html"><button>Shop Now</button></a>
        </div>
    </section>

    <section class="categories">
        <div class="category">
            <a href="skincare.html"><img src="WhatsApp Image 2024-10-23 at 22.41.25.jpeg" alt="Skincare"></a>
            <h3>Skincare</h3>
        </div>
        <div class="category">
           <a href="bodycare.html"> <img src="WhatsApp Image 2024-10-23 at 22.41.21.jpeg" alt="Bodycare"></a>
            <h3>Bodycare</h3>
        </div>
        <div class="category">
            <a href="haircare.html"> <img src="WhatsApp Image 2024-10-23 at 22.41.29.jpeg" alt="Haircare"></a>
            <h3>Haircare</h3>
        </div>
    </section>
<br> <br>
    <footer>
        <div class="footer-links">
            <ul>
                <li><a href="aboutus.html">About Us</a></li>
                <li><a href="c.html">Contact</a></li>
                <li><a href="pp.html">Privacy Policy</a></li>
                <li><a href="t&c.html">Terms & Conditions</a></li>
            </ul>
        </div>
        <div class="social-media">
            <a href="#">Facebook</a> | 
            <a href="#">Instagram</a> | 
            <a href="#">Twitter</a>
        </div>
        <p>&copy; 2023 Nazakat. All rights reserved.</p>
    </footer>

    <script src="dropdown.js"></script>
</body>
</html>
