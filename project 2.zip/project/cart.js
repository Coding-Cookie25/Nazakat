// Sample product data
const products = [
    { name: "Product 1", price: 100 },
    { name: "Product 2", price: 200 },
    { name: "Product 3", price: 300 }
];

// Function to display products
function showProductGallery() {
    const productGrid = document.getElementById('product-grid');
    products.forEach((product, index) => {
        const productDiv = document.createElement('div');
        productDiv.innerHTML = `
            <h3>${product.name}</h3>
            <p>Price: $${product.price.toFixed(2)}</p>
            <input type="number" value="1" min="1" id="quantity-${index}" />
            <button onclick="addToCart(${index})">Add to Cart</button>
        `;
        productGrid.appendChild(productDiv);
    });
}

// Function to add products to the cart
function addToCart(index) {
    const quantity = document.getElementById(`quantity-${index}`).value;
    const product = products[index];
    const cartTableBody = document.getElementById('cartTableBody');

    // Create a new row for the cart
    const row = document.createElement('tr');
    const subtotal = product.price * quantity;

    row.innerHTML = `
        <td>${product.name}</td>
        <td>$${product.price.toFixed(2)}</td>
        <td>${quantity}</td>
        <td>$${subtotal.toFixed(2)}</td>
    `;
    cartTableBody.appendChild(row);

    // Update total amount
    updateTotal();
}

// Function to calculate the total price
function updateTotal() {
    const cartTableBody = document.getElementById('cartTableBody');
    const rows = cartTableBody.getElementsByTagName('tr');
    let total = 0;

    for (let row of rows) {
        const subtotal = parseFloat(row.cells[3].textContent.replace('$', ''));
        total += subtotal;
    }

    document.getElementById('totalAmount').textContent = `$${total.toFixed(2)}`;
}

// Initialize the product gallery on page load
window.onload = showProductGallery;
